/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package examination.registration;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author ssoracle.jdbc.driver.OracleDriver
 */
public class databaseconnection {
    final static String JDBC_DRIVER="oracle.jdbc.driver.OracleDriver";
    final static String DB_URL="jdbc:oracle:thin:@localhost:1521:root";
    final static String USER="system";
    final static String PASS="root";
 
    public static Connection connection(){
        try{
        
            Class.forName(JDBC_DRIVER);
            
            Connection conn=DriverManager.getConnection(DB_URL,USER,PASS);
            
            
            
            return conn;
        }catch(Exception e){
            System.out.println(e);
         return null;
        }
    }
}
